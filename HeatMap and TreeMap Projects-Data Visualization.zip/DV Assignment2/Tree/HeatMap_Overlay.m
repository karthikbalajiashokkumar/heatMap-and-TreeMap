
% img = image on which to overlay heatmap
% heatmap = the heatmap
% (optional) colorfunc .. this can be 'jet' , or 'hot' , or 'flag'

function omap = heatmapoverlay( image , asgn2, colorfun )

if (strcmp(class(image),'char') == 1 ) image = imread(image); end
if ( strcmp(class(image),'uint8') == 1 ) image = double(image)/255; end

szh = size(asgn2);
szi = size(image);

if ( (szh(1)~=szi(1)) | (szh(2)~=szi(2)) )
  asgn2 = imresize( asgn2 , [ szi(1) szi(2) ] , 'bicubic' );
end
  
if ( size(image,3) == 1 )
  image = repmat(image,[1 1 3]);
end
  
if ( nargin == 2 )
    colorfun = 'parula';
end
colorfunc = eval(sprintf('%s(50)',colorfun));

asgn2 = double(asgn2);
asgn2 = asgn2/ max(asgn2(:));
omap = 0.8*(1-repmat(asgn2.^0.8,[1 1 3])).*double(image)/max(double(image(:))) + repmat(asgn2.^0.8,[1 1 3]).* shiftdim(reshape( interp2(1:3,1:50,colorfunc,1:3,1+49*reshape( asgn2 , [ prod(size(asgn2))  1 ] ))',[ 3 size(asgn2) ]),1);
omap = real(omap);