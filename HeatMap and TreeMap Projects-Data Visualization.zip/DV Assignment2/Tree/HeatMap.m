close all;
clear all;
clc;

image = imread('Input Image.jpg');
figure, imshow(image);

fix=zeros(508,850);           
fix(136,206)=1;
fix(346,246)=1;
fix(332,247)=1;
fix(311,217)=1;
fix(96,226)=1;
fix(97,230)=1;
fix(150,246)=1;
fix(412,170)=1;
fix(146,507)=1;
fix(144,492)=1;
fix(345,172)=1;
fix(358,196)=1;
fix(368,172)=1;
fix(347,352)=1;
fix(155,665)=1;
fix(276,163)=1;
fix(241,583)=1;
fix(254,171)=1;
fix(63,181)=1;
fix(217,327)=1;
fix(235,592)=1;
fix(285,537)=1;
fix(174,325)=1;
fix(225,495)=1;
fix(45,73)=1;
fix(69,87)=1;
fix(43,397)=1;
fix(57,402)=1;
fix(79,562)=1;
fix(22,74)=1;
fix(105,119)=1;
fix(117,120)=1;
fix(150,170)=1;

figure, imshow(fix,[]);
   
gaussian_kernel = fspecial('gaussian',[100 100],20);
density = imfilter(fix, gaussian_kernel, 'replicate');
figure, imshow(density,[]);


omask = heatmapoverlay(image, density, 'parula');
figure,imshow(omask);
colormap(parula);
colorbar;
colorbar('Ticks',[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1],...
         'TickLabels',{'0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'})
     title('Apple Google Search Page')
    
