function plotRectangles(rectangles,labels,colors,layers)
if(nargin < 2)
labels = [];
end
if(nargin < 3)
colors = rand(size(rectangles,2),3).^0.5;
end
for i = 1:size(rectangles,2)
r = rectangles(:,i);
xPoints = [r(1), r(1), r(1) + r(3),r(1) + r(3)];
yPoints = [r(2), r(2)+ r(4), r(2)+ r(4),r(2)];

if(~isempty(labels))
    if layers == 1
        patch(xPoints,yPoints,colors(i,:),'EdgeColor','none');
        text(r(1) + r(3)/2,r(2) + r(4)/2, 1, labels{i}, 'VerticalAlignment','top','HorizontalAlignment','center','color','white','BackgroundColor','[0.5 0.5 0.5]','EdgeColor','white','clipping' ,'on','FontSize',16)
    else
     
        patch(xPoints,yPoints,colors(i,:), 'FaceColor','none','EdgeColor','none');
        text(r(1) + r(3)/2,r(2) + r(4)/2, 1,   labels{i}, 'VerticalAlignment','top','HorizontalAlignment','center','color','white','clipping' ,'on','FontSize',14);
    end
end
axis equal
axis tight
axis off
end
