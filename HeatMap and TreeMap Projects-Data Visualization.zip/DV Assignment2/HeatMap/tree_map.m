close all;
clear all;
clc;

data={'iPhone','11 Pro Max',1099;
'iPhone','11 Pro',999;
'iPhone','11',800;
'iPhone','XS Max',850;
'iPhone','X/XS',750;
'iPhone','XR',650;
'iPhone','8,7,6',449;
'Watch','Series 5',470;
'Watch','Series 4',340;
'Watch','Series 3',199;
'MacBook','Pro 16"',2399;
'MacBook','Pro 13"',1299;
'MacBook','Air',1099;
'AirPods','AirPods Pro',249;
'AirPods','AirPods',199;
'iPad','iPad',329;
'iPad','iPad Mini',399;
'iPad','iPad Pro',799;
'iPad','iPad Air',499;};


names={'iPhone','Watch','MacBook','AirPods','iPad'};
colors = rand(5,3); %for generating different colour combinations
%disp (colors);
temp = zeros(19,5);
for i = 1:5
    for j = 1:19
       if strcmp(names(i),data(j,1))==1
            C = cell2mat(data(j,3));     
            temp(j,i) = C;                  
       end
   end
end
%disp (temp);
level = sum(temp);
rectangles = treemap(level);
plotRectangles(rectangles,names,colors,1);
outline(rectangles);

  for j = 1:5
      colors = (3 * repmat(rand(1,3),19,1))/4;
      Newtree = treemap(temp(:,j),rectangles(3,j),rectangles(4,j));
      Newtree(1,:) = Newtree(1,:) + rectangles(1,j);
      Newtree(2,:) = Newtree(2,:) + rectangles(2,j);
      plotRectangles(Newtree,data(:,2),colors,2)
      outline(Newtree);
  end

